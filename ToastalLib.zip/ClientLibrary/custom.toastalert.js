﻿function ToastandRedirectURL(toasttype, url, title, msg, cssclass, timeout, ShowCloseButton, DoDebug, NewOnTop, ShowProgressBar, PreventDuplicate, ShowDuration, HideDuration, ExtendTimeout, ShowEasing, HideEasing, ShowMethod, HideMethod, TapToDismiss) {

    if (parseInt(toasttype) === 1) {
        ShowSuccessToast(title, msg, cssclass, timeout, ShowCloseButton, DoDebug, NewOnTop, ShowProgressBar, PreventDuplicate, ShowDuration, HideDuration, ExtendTimeout, ShowEasing, HideEasing, ShowMethod, HideMethod, TapToDismiss);
    }
    else if (parseInt(toasttype) === 2) {
        ShowErrorToast(title, msg, cssclass, timeout, ShowCloseButton, DoDebug, NewOnTop, ShowProgressBar, PreventDuplicate, ShowDuration, HideDuration, ExtendTimeout, ShowEasing, HideEasing, ShowMethod, HideMethod, TapToDismiss);
    }
    else if (parseInt(toasttype) === 3) {
        ShowWarningToast(title, msg, cssclass, timeout, ShowCloseButton, DoDebug, NewOnTop, ShowProgressBar, PreventDuplicate, ShowDuration, HideDuration, ExtendTimeout, ShowEasing, HideEasing, ShowMethod, HideMethod, TapToDismiss);
    }

    if (url !== 'NA') {
        window.setTimeout(function () {
            window.location.href = url;
        }, parseInt(timeout));
    }
}

function ShowSuccessToast(title, msg, cssclass, timeout, ShowCloseButton, DoDebug, NewOnTop, ShowProgressBar, PreventDuplicate, ShowDuration, HideDuration, ExtendTimeout, ShowEasing, HideEasing, ShowMethod, HideMethod, TapToDismiss) {
    toastr.success(msg, title, {
        "positionClass": cssclass,
        "timeOut": timeout,
        "closeButton": ShowCloseButton,
        "debug": DoDebug,
        "newestOnTop": NewOnTop,
        "progressBar": ShowProgressBar,
        "preventDuplicates": PreventDuplicate,
        "onclick": null,
        "showDuration": parseInt(ShowDuration),
        "hideDuration": parseInt(HideDuration),
        "extendedTimeOut": parseInt(ExtendTimeout),
        "showEasing": ShowEasing,
        "hideEasing": HideEasing,
        "showMethod": ShowMethod,
        "hideMethod": HideMethod,
        "tapToDismiss": TapToDismiss
    });
}

function ShowErrorToast(title, msg, cssclass, timeout, ShowCloseButton, DoDebug, NewOnTop, ShowProgressBar, PreventDuplicate, ShowDuration, HideDuration, ExtendTimeout, ShowEasing, HideEasing, ShowMethod, HideMethod, TapToDismiss) {
    toastr.error(msg, title, {
        "positionClass": cssclass,
        "timeOut": timeout,
        "closeButton": ShowCloseButton,
        "debug": DoDebug,
        "newestOnTop": NewOnTop,
        "progressBar": ShowProgressBar,
        "preventDuplicates": PreventDuplicate,
        "onclick": null,
        "showDuration": parseInt(ShowDuration),
        "hideDuration": parseInt(HideDuration),
        "extendedTimeOut": parseInt(ExtendTimeout),
        "showEasing": ShowEasing,
        "hideEasing": HideEasing,
        "showMethod": ShowMethod,
        "hideMethod": HideMethod,
        "tapToDismiss": TapToDismiss
    });
}

function ShowWarningToast(title, msg, cssclass, timeout, ShowCloseButton, DoDebug, NewOnTop, ShowProgressBar, PreventDuplicate, ShowDuration, HideDuration, ExtendTimeout, ShowEasing, HideEasing, ShowMethod, HideMethod, TapToDismiss) {
    toastr.warning(msg, title, {
        "positionClass": cssclass,
        "timeOut": timeout,
        "closeButton": ShowCloseButton,
        "debug": DoDebug,
        "newestOnTop": NewOnTop,
        "progressBar": ShowProgressBar,
        "preventDuplicates": PreventDuplicate,
        "onclick": null,
        "showDuration": parseInt(ShowDuration),
        "hideDuration": parseInt(HideDuration),
        "extendedTimeOut": parseInt(ExtendTimeout),
        "showEasing": ShowEasing,
        "hideEasing": HideEasing,
        "showMethod": ShowMethod,
        "hideMethod": HideMethod,
        "tapToDismiss": TapToDismiss
    });
}